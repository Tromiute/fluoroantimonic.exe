++++++++   +         +            +
+                 +         +            +
++++++++   +         +            +
+                 +         +            +   oroantimonic.exe
+                 +          +++++++
+                 +++++

made by Xuepiao (aka compaq deskpro2000 (aka tromiute))

---- about fluoroantimonic ------
6 payload 5 bytebeat 
to chance icon 
make in c++

---- for skidder ----
but almium mbr
....
maze game mbr
who stop reshacked